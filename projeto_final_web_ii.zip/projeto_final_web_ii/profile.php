<?php 
include "const.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content=" <?= DESCRIPTION ?> ">
    <meta name="keywords" content="php, css, html, javascript, vscode, site, login">
    <meta name="author" content="  <?= AUTHOR ?> ">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Projeto Final Web II</title>
</head>
<body>
    <h3 style="font-size: 30pt; text-align: center;">MEU PERFIL</h3>
    <hr>
    <img src="assets/img/img_usuario.png" alt="foto de usuário" style="width:150px;">
    <br>
    <table>
        <tr>
            <td><input type="text" name="name" id="name" placeholder="Nome completo"></td>
            <td><input type="text" name="user-name" id="user-name" placeholder="Nome de usuário" style="margin-left: 15px;"></td>
        </tr>
        <tr>
        <td><input type="text" name="zip-code" id="zip-code" placeholder="CPF   "></td>
            <td><input type="text" name="rg" id="rg" placeholder="RG" style="margin-left: 15px;"></td>
        </tr>
        <td><input type="text" name="email" id="email" placeholder="Email"></td>
            <td><input type="text" name="phone" id="phone" placeholder="Telefone" style="margin-left: 15px;"></td>
        </td>
        <tr>
        <td><input type="password" name="password" id="password" placeholder="Senha"></td>
            <td><input type="password" name="password2" id="password2" placeholder="Confirmar senha" style="margin-left: 15px;"></td>
        </tr>
    </table>
</body>
</html>