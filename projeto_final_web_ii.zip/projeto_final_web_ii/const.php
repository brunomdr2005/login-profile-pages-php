<?php

define ("AUTHOR", "Rocha, Bruno Machado");
define ("DESCRIPTION", "php, css, html, javascript, vscode, site, login");