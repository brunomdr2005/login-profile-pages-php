<?php 
//Código PHP

include "./const.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content=" <?= DESCRIPTION ?> ">
    <meta name="keywords" content="php, css, html, javascript, vscode, site, login">
    <meta name="author" content="  <?= AUTHOR ?> ">
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Projeto Final Web II</title>
</head>
<body>
    <img src="./assets/img/img_professor.png" alt="imagem de um professor e um aluno numa aula" title="Professor e aluno" id = "img_professor">
    <div class="container-index">
    <h1 id="text_login">LOGIN</h1>
    <form action="#" method="post">
        <input type="text" name="user" id="user" class="login" placeholder="Usuário">
        <br>
        <input type="password" name="pass" id="pass" class="login" placeholder="Senha">
        <br>
        <input type="submit" value="ENTRAR" id="btn_entrar">
    </form>
    </div>
</body>
</html>